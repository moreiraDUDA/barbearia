package Modelo;

public class ClienteM {
    private String nome;
    private String telefone;
    
    public ClienteM(){
        this.nome = " ";
        this.telefone = " ";
    }

    public ClienteM(String nome, String telefone) {
        this.nome = nome;
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    
}
