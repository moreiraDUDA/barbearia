/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author maria
 */
public class DataM {
    private String ddmm;
    private String horario;
    
    public DataM(){
        this.ddmm = "";
        this.horario = "";
    }

    public DataM(String ddmm, String horario) {
        this.ddmm = ddmm;
        this.horario = horario;
    }

    public String getDdmm() {
        return ddmm;
    }

    public void setDdmm(String ddmm) {
        this.ddmm = ddmm;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }
     
    
}
