/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Conexao.Conexao;
import Modelo.DataM;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author maria
 */
public class DataDAO {
     public void inserirData(DataM a) {
        try{
            String SQL = "INSERT INTO mariaeliza.data (ddmm, horario) VALUES (?, ?,)";
            Connection conect = Conexao.getConexao();
            PreparedStatement comandoSQL = conect.prepareStatement(SQL);
            comandoSQL.setString(1, a.getDdmm());
            comandoSQL.setString(2, a.getHorario());
            int retorno = comandoSQL.executeUpdate();
            conect.close();
            
            if(retorno>0){
                JOptionPane.showMessageDialog(null,"Horário inserido com sucesso.");
            }
            else{
                JOptionPane.showMessageDialog(null,"Erro ao inserir horário"+ "\n VERIFIQUE OS LOGS");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
