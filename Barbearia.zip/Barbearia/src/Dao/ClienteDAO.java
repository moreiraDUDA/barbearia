package Dao;

import Conexao.Conexao;
import Modelo.ClienteM;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author maria
 */
public class ClienteDAO {
    public void inserirCliente(ClienteM a) {
        try{
            String SQL = "INSERT INTO mariaeliza.cliente (nome, telefone) VALUES (?, ?,)";
            Connection conect = Conexao.getConexao();
            PreparedStatement comandoSQL = conect.prepareStatement(SQL);
            comandoSQL.setString(1, a.getNome());
            comandoSQL.setString(2, a.getTelefone());
            int retorno = comandoSQL.executeUpdate();
            conect.close();
            
            if(retorno>0){
                JOptionPane.showMessageDialog(null,"Cliente "+a.getNome()+" inserido com sucesso.");
            }
            else{
                JOptionPane.showMessageDialog(null,"Erro ao inserir cliente "+a.getNome()+ "\n VERIFIQUE OS LOGS");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
    

