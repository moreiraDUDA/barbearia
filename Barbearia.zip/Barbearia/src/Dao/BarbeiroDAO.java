package Dao;

import Conexao.Conexao;
import Modelo.BarbeiroM;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author maria
 */
public class BarbeiroDAO {
    public void inserirBarbeiro(BarbeiroM a) {
        try{
            String SQL = "INSERT INTO mariaeliza.cliente (nome) VALUES (?,)";
            Connection conect = Conexao.getConexao();
            PreparedStatement comandoSQL = conect.prepareStatement(SQL);
            comandoSQL.setString(1, a.getNome());
            int retorno = comandoSQL.executeUpdate();
            conect.close();
            
            if(retorno>0){
                JOptionPane.showMessageDialog(null,"Barbeiro "+a.getNome()+" inserido com sucesso.");
            }
            else{
                JOptionPane.showMessageDialog(null,"Erro ao inserir Barbeiro "+a.getNome()+ "\n VERIFIQUE OS LOGS");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
    

